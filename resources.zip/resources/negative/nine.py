import pandas as pd
import random
import os

# ===================== 路径读取 =====================
pairs = pd.read_csv("../24对_中等相似度配对表.csv")
neutral = [f"neutral/{f}" for f in os.listdir("../neutral") if f.endswith(('jpg','png'))]
negative = [f"negative/{f}" for f in os.listdir("../negative") if f.endswith(('jpg','png'))]
negative = negative[:24]  # 强制只用前24张，保证一一对应

pair_dict = dict(zip(pairs["neutral"], pairs["social"]))
all_trials = []

# ===================== 1 无干扰 24个 =====================
for img in neutral:
    others = random.sample([x for x in neutral if x != img], 8)
    grid = [img] + others
    random.shuffle(grid)
    grid_str = ",".join(grid)

    all_trials.append({
        "type": 1,
        "type_name": "无干扰",
        "has_target": 1,
        "target_img": img,
        "nine_images": grid_str,
        "correct_key": "f"
    })

# ===================== 2 社交干扰 24个 =====================
for img in neutral:
    social_dist = pair_dict[img]
    others = random.sample([x for x in neutral if x != img], 7)
    grid = [img, social_dist] + others
    random.shuffle(grid)
    grid_str = ",".join(grid)

    all_trials.append({
        "type": 2,
        "type_name": "社交干扰",
        "has_target": 1,
        "target_img": img,
        "nine_images": grid_str,
        "correct_key": "f"
    })

# ===================== 3 情绪干扰 24个（负性图全部用完！） =====================
random.shuffle(negative)  # 打乱负性图
for img, neg_dist in zip(neutral, negative):
    others = random.sample([x for x in neutral if x != img], 7)
    grid = [img, neg_dist] + others
    random.shuffle(grid)
    grid_str = ",".join(grid)

    all_trials.append({
        "type": 3,
        "type_name": "情绪干扰",
        "has_target": 1,
        "target_img": img,
        "nine_images": grid_str,
        "correct_key": "f"
    })

# ===================== 4 无目标 24个 =====================
for _ in range(24):
    fake_target = random.choice(neutral)
    grid = random.sample(neutral, 9)
    grid_str = ",".join(grid)

    all_trials.append({
        "type": 4,
        "type_name": "无目标",
        "has_target": 0,
        "target_img": fake_target,
        "nine_images": grid_str,
        "correct_key": "space"
    })

# ===================== 打乱 + 编号 + 保存 =====================
random.shuffle(all_trials)
df = pd.DataFrame(all_trials)
df.insert(0, "trial_id", range(1, 97))

df.to_csv("../96试次_最终完美版.csv", index=False, encoding="utf-8-sig")

print("✅ 生成完成！")
print("总试次：", len(df))
print("四类各 24 个")
print("负性图片 24 张全部用完，不重复！")